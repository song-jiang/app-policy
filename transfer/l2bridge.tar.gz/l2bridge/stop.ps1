
taskkill /im kubelet.exe /f
taskkill /im kube-proxy.exe /f
taskkill /im flanneld.exe /f